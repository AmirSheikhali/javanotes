package org.example;

public class HelloDatabase {
}
