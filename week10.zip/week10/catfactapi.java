import kong.unirest.Unirest;

public class catfactapi {
    public static void main(String[] args) {
        String url ="https://catfact.ninja/fact";
        Catfact Catfact = Unirest.get(url).asObject(Catfact.class).getBody();
        String fact = Catfact.getFact();
        System.out.println(Catfact.getFact());
        int factLength = Catfact.getLength();
        System.out.println("The fact is " + factLength + " characters long");
    }
}
class Catfact{
    private String fact;
    private int length;

    public int getLength() {
        return length;
    }

    public String getFact() {
        return fact;
    }
}