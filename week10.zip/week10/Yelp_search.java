public class Yelp_search {
    public static void main(String[] args) {
        String yelpUrl = "https://api.yelp.com/v3/businesses/search";
        String YELP_API_KEY = "";

    }

}
