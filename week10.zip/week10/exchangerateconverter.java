import kong.unirest.Unirest;

import java.util.Map;

public class exchangerateconverter {
    public static void main(String[] args) {
        String url = "https://exchange-rates-1150.herokuapp.com/latest";
        Map<String,Object> queryParameters = Map.of("base","USD","symbols","EUR");
        RateResponse response = Unirest.get(url).queryString(queryParameters) .asObject(RateResponse.class).getBody();
        String dateRequested = response.date;
        double rate = response.rates.EUR;
        System.out.println("On"+ dateRequested + " the exchange rate from USD to Euros is" + rate);

    }
}
class RateResponse {
    public String base ;
    public String date;
    public Rates rates;
}
class Rate {
   public double EUR;
}
