import kong.unirest.Unirest;

public class bustime_table {
    public static void main(String[] args) {
        String busTimeUrl = "https://svc.metrotransit.org/NexTrip/17940?format=json";
        Bus[]busses = Unirest.get(busTimeUrl).asObject(Bus[].class).getBody();
        for (Bus bus: busses) {
            System.out.println(bus.Route + bus.Description + bus.DepartureText);
        }


    }
}
class Bus{
    public String DepartureText;
    public String Route;
    public String Description;
}