public class Yelp_response {
    public Business[] business;
}
class Business{
    public String name;
    public double rating;

}
