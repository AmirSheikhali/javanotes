package week6;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class hellowriting {
    public static void main(String[] args) throws IOException {
        FileWriter writer =new FileWriter("Hello.txt");
        BufferedWriter bufferedwriter = new BufferedWriter(writer);
        bufferedwriter.write("Hello!\n");
        bufferedwriter.write("More data here \n");
        bufferedwriter.write("Goodbye!\n");
        bufferedwriter.close();


    }
}
