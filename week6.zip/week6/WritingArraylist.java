package week6;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WritingArraylist {
    public static  void main(String[] args) throws IOException {
       List<String> classNames = new ArrayList<>();
       List<String> classes = new ArrayList<>();
      // classes.add("java");
      // classes.add("web");
      // classNames.add("C#");
        List<Interger> classCode= List.of(2545, 2560, 2505);
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("ITEC_Classes.txt"));
        for (String name: classNames){
            bufferedWriter.write(name + "\n");
        }
        bufferedWriter.close();
    }
}
