package week6;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class name {
    public static void main(String[] args) throws IOException {
        String name = "Amir";
        String FavoriteColor = "red";
        int classCode = 2454;
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("info.txt"));
        bufferedWriter.write(name +"\n");
        bufferedWriter.write(FavoriteColor);
        bufferedWriter.newLine();
        bufferedWriter.write(classCode +"\n");
        bufferedWriter.close();

    }
}
